export interface ContactModel {
  id: string;
  firstname: string;
  lastname: string;
  mobile: number;
  home: number;
  email: string;
  imagePath: string;
}
